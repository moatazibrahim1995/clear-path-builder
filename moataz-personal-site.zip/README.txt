Deploy notes:
1) Upload index.html and the assets/ folder.
2) The language toggle switches EN/AR sitewide and remembers preference.
3) Calendly booking is wired in the navbar and the Hire section.